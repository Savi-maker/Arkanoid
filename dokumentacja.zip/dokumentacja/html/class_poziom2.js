var class_poziom2 =
[
    [ "~Poziom2", "class_poziom2.html#a7fcd6a4f90217bddb5a918e307ead3ab", null ],
    [ "Start", "class_poziom2.html#a2b01ba9403e0e763aa22011995ef5551", null ]
];