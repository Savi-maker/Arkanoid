var class_score_manager =
[
    [ "ScoreManager", "class_score_manager.html#a8952a17614ae60b3191a812728bd55fc", null ],
    [ "addScore", "class_score_manager.html#a842a2834c5bb44d292e3f054d2612240", null ],
    [ "getScores", "class_score_manager.html#a6c3d036e25b3c2cea4e34ed8c00442e8", null ],
    [ "loadScores", "class_score_manager.html#a91233469cc1823684930654b9a33af91", null ],
    [ "saveScores", "class_score_manager.html#aa3f390fe5076324b2d457de0c43af59f", null ]
];