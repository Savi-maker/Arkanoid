var _poziom1_8cpp =
[
    [ "collisionTestBlockBall", "_poziom1_8cpp.html#a5f41ef30c60241031aa2f385855c936a", null ],
    [ "collisionTestBuffPaddle", "_poziom1_8cpp.html#af5671b0fb3c814cc89489b04ff274144", null ],
    [ "collisionTestPaddleBall", "_poziom1_8cpp.html#acb7d816b93afeca8683a1c37667c7731", null ],
    [ "isGameOver1", "_poziom1_8cpp.html#aa35579658bd2ad5db107a061421634d6", null ]
];