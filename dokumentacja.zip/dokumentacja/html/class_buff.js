var class_buff =
[
    [ "Buff", "class_buff.html#a3f6d21319373cfbff38ccab91cddc84e", null ],
    [ "Buff", "class_buff.html#aced615c356d70720f4e48bb4fa282068", null ],
    [ "activate", "class_buff.html#af93e7a2b9336e72e423c18a1c53c70c5", null ],
    [ "bottom", "class_buff.html#a6c776af10f3284dee66fa2f1d3a9c404", null ],
    [ "deactivate", "class_buff.html#a396ac635b52e27f5c1452bdad9885270", null ],
    [ "draw", "class_buff.html#a32537ed93528bd71e3828ab200b0cdde", null ],
    [ "fall", "class_buff.html#a8b4679a61a8bed9a7ec015f6a0968697", null ],
    [ "getType", "class_buff.html#a42fcc80f65cb698315a41fe383d00f52", null ],
    [ "isEffectActive", "class_buff.html#a123a908ce77c8185f0b397bd216e817c", null ],
    [ "isEffectEnded", "class_buff.html#aaf953b3839cbabb8c0996e31e4b60f2e", null ],
    [ "left", "class_buff.html#af766217ac14ed2fd2f5a8b80d57f3ae6", null ],
    [ "operator=", "class_buff.html#aea1d945019a79aff0e90cadc1b3529e2", null ],
    [ "resetEffect", "class_buff.html#aa6eb871d1a1442256cc9b6d9a66ec8a8", null ],
    [ "right", "class_buff.html#abf7c917bd448aa368d75d073503f3db3", null ],
    [ "top", "class_buff.html#a098f320e96059ce20a4cfdbcf6d8a195", null ],
    [ "update", "class_buff.html#a9ce2f0ea85fa26ae1f0689af0bfb972f", null ],
    [ "updateEffect", "class_buff.html#a22673ab2a49cb9c7b68331ce2bcd6897", null ]
];