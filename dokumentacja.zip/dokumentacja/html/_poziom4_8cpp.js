var _poziom4_8cpp =
[
    [ "collisionTest4", "_poziom4_8cpp.html#a7e122c26c87de4fb52159e729896a6b9", null ],
    [ "collisionTest4", "_poziom4_8cpp.html#a7c013869a75b17cdda4796c279c447cf", null ],
    [ "isGameOver4", "_poziom4_8cpp.html#a753e59fcd3a3a5008ae430a11c27d234", null ],
    [ "isIntersecting4", "_poziom4_8cpp.html#ade87fbef927fdeee5a9177e9cff8c6db", null ]
];