var _okno_menu_8cpp =
[
    [ "main", "_okno_menu_8cpp.html#acdef7a1fd863a6d3770c1268cb06add3", null ]
];