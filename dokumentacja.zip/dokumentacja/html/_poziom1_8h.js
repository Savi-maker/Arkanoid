var _poziom1_8h =
[
    [ "Poziom1", "class_poziom1.html", "class_poziom1" ],
    [ "isIntersecting1", "_poziom1_8h.html#a5a94895352909842920a625e139de01a", null ]
];