var annotated_dup =
[
    [ "Ball", "class_ball.html", "class_ball" ],
    [ "Block", "class_block.html", "class_block" ],
    [ "Buff", "class_buff.html", "class_buff" ],
    [ "MainMenu", "class_main_menu.html", "class_main_menu" ],
    [ "Paddle", "class_paddle.html", "class_paddle" ],
    [ "Poziom1", "class_poziom1.html", "class_poziom1" ],
    [ "Poziom2", "class_poziom2.html", "class_poziom2" ],
    [ "Poziom3", "class_poziom3.html", "class_poziom3" ],
    [ "Poziom4", "class_poziom4.html", "class_poziom4" ],
    [ "Poziom5", "class_poziom5.html", "class_poziom5" ],
    [ "Poziom6", "class_poziom6.html", "class_poziom6" ],
    [ "ScoreManager", "class_score_manager.html", "class_score_manager" ]
];