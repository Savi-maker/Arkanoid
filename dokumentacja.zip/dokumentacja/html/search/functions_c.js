var searchData=
[
  ['savescores_0',['saveScores',['../class_score_manager.html#aa3f390fe5076324b2d457de0c43af59f',1,'ScoreManager']]],
  ['scoremanager_1',['ScoreManager',['../class_score_manager.html#a8952a17614ae60b3191a812728bd55fc',1,'ScoreManager']]],
  ['setinvisible_2',['setInvisible',['../class_ball.html#a8445dbb07dda6358b3b29e642e335820',1,'Ball']]],
  ['setradius_3',['setRadius',['../class_ball.html#a7f8d844948ccc5111ee4b60cdb3ed42f',1,'Ball']]],
  ['setreversecontrols_4',['setReverseControls',['../class_paddle.html#a63e52094b6c463cafe6260333d59ebd3',1,'Paddle']]],
  ['setsize_5',['setSize',['../class_paddle.html#af4eea860e4c267644e5da8f7fe2446a6',1,'Paddle']]],
  ['setvelocity_6',['setVelocity',['../class_ball.html#a9b4ac3f1e7a76104005df37e954e3ff0',1,'Ball::setVelocity()'],['../class_paddle.html#a2acdc3dc0a8fd8d4b9c6e7acf593a26f',1,'Paddle::setVelocity()']]],
  ['start_7',['Start',['../class_poziom1.html#a03dd1f10b4eee21dc538122f20572952',1,'Poziom1::Start()'],['../class_poziom2.html#a2b01ba9403e0e763aa22011995ef5551',1,'Poziom2::Start()'],['../class_poziom3.html#a7683e562ee6b3a282804cfa55c0f917b',1,'Poziom3::Start()'],['../class_poziom4.html#af5d072e0a8ad9c32a3e4e8a724973531',1,'Poziom4::Start()'],['../class_poziom5.html#a7663dfb5546758ffd4a97fa1901798ed',1,'Poziom5::Start()'],['../class_poziom6.html#a0f0f0efb08690647d33d9486efb1c5ed',1,'Poziom6::Start()']]]
];
