var searchData=
[
  ['invisibilityclock_0',['invisibilityClock',['../class_ball.html#a0361fc18a91dede32a2cb0c90a2cfb6d',1,'Ball']]],
  ['invisibilityduration_1',['invisibilityDuration',['../class_ball.html#a8c216b45c93e9020617ee8f1bd3abd87',1,'Ball']]],
  ['isdestroyed_2',['isDestroyed',['../class_block.html#a6851e32c68661625e5b2bde310f53c90',1,'Block']]],
  ['iseffectactive_3',['isEffectActive',['../class_buff.html#a123a908ce77c8185f0b397bd216e817c',1,'Buff']]],
  ['iseffectended_4',['isEffectEnded',['../class_buff.html#aaf953b3839cbabb8c0996e31e4b60f2e',1,'Buff']]],
  ['isgameover1_5',['isGameOver1',['../_poziom1_8cpp.html#aa35579658bd2ad5db107a061421634d6',1,'Poziom1.cpp']]],
  ['isgameover2_6',['isGameOver2',['../_poziom2_8cpp.html#a312d0bb8597f68b7c29530de0d62221d',1,'Poziom2.cpp']]],
  ['isgameover3_7',['isGameOver3',['../_poziom3_8cpp.html#aa6c822ac00c8f571cfeb3d271eb95dd3',1,'Poziom3.cpp']]],
  ['isgameover4_8',['isGameOver4',['../_poziom4_8cpp.html#a753e59fcd3a3a5008ae430a11c27d234',1,'Poziom4.cpp']]],
  ['isgameover5_9',['isGameOver5',['../_poziom5_8cpp.html#a48427f0a2a6dda922042e369959a9858',1,'Poziom5.cpp']]],
  ['isgameover6_10',['isGameOver6',['../_poziom6_8cpp.html#af44b45924249f4c25e9116df6ba26004',1,'Poziom6.cpp']]],
  ['isintersecting_11',['isIntersecting',['../_utils_8h.html#ab11ab8517b09e802f3c68248b310baf9',1,'isIntersecting(T1 &amp;A, T2 &amp;B):&#160;Utils.h'],['../_utils_8h.html#a3f602ccd743ac04e75c7c90feb6873bf',1,'isIntersecting(T1 &amp;A, T2 &amp;B, float offsetX, float offsetY):&#160;Utils.h']]],
  ['isintersecting1_12',['isIntersecting1',['../_poziom1_8h.html#a5a94895352909842920a625e139de01a',1,'Poziom1.h']]],
  ['isintersecting2_13',['isIntersecting2',['../_poziom2_8cpp.html#abc1a4fbb2d436dfa5ad278f7ac8585ff',1,'Poziom2.cpp']]],
  ['isintersecting3_14',['isIntersecting3',['../_poziom3_8cpp.html#aa8d9c4b4ae78dc69f6f707b1fb23c6f8',1,'Poziom3.cpp']]],
  ['isintersecting4_15',['isIntersecting4',['../_poziom4_8cpp.html#ade87fbef927fdeee5a9177e9cff8c6db',1,'Poziom4.cpp']]],
  ['isintersecting5_16',['isIntersecting5',['../_poziom5_8cpp.html#af884b88b5b62a2c0e835465902403033',1,'Poziom5.cpp']]],
  ['isintersecting6_17',['isIntersecting6',['../_poziom6_8cpp.html#a876c66484f00ec7ad12fc5bac6c3bc00',1,'Poziom6.cpp']]]
];
