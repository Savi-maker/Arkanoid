var searchData=
[
  ['ballspeeddown_0',['BallSpeedDown',['../_buff_8h.html#af2698b3717f3617f4450dcd130fd3529a3331688e04c3eeee017b4a6f7d945231',1,'Buff.h']]],
  ['ballspeedup_1',['BallSpeedUp',['../_buff_8h.html#af2698b3717f3617f4450dcd130fd3529ab58fa10f2874c80405aae5c4529f166d',1,'Buff.h']]]
];
