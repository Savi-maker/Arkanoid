var searchData=
[
  ['update_0',['update',['../class_ball.html#af30f4707d26a6e7ba0af1dd8cac37684',1,'Ball::update()'],['../class_ball.html#a794dcba9bdcb13c1efc14ef97f185fe5',1,'Ball::update(const Paddle &amp;paddle)'],['../class_block.html#a10e17f44df4d273c16190732197578f2',1,'Block::update()'],['../class_buff.html#a9ce2f0ea85fa26ae1f0689af0bfb972f',1,'Buff::update()'],['../class_paddle.html#a840b626b2137bb9f754563d33693cfac',1,'Paddle::update()']]],
  ['updateeffect_1',['updateEffect',['../class_buff.html#a22673ab2a49cb9c7b68331ce2bcd6897',1,'Buff']]],
  ['updateinvisibility_2',['updateInvisibility',['../class_ball.html#ae5fe0d626dfc5c0b7fb06d4e9f3f45a6',1,'Ball']]],
  ['utils_2eh_3',['Utils.h',['../_utils_8h.html',1,'']]]
];
