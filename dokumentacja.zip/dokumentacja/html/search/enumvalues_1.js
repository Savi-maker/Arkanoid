var searchData=
[
  ['paddlespeeddown_0',['PaddleSpeedDown',['../_buff_8h.html#af2698b3717f3617f4450dcd130fd3529a6790015c0998d9520b6fd236571421c5',1,'Buff.h']]],
  ['paddlespeedup_1',['PaddleSpeedUp',['../_buff_8h.html#af2698b3717f3617f4450dcd130fd3529a704d112cbc3504a3e29bd0ab67988481',1,'Buff.h']]]
];
