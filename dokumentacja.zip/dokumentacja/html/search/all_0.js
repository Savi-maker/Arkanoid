var searchData=
[
  ['activate_0',['activate',['../class_buff.html#af93e7a2b9336e72e423c18a1c53c70c5',1,'Buff']]],
  ['addscore_1',['addScore',['../class_score_manager.html#a842a2834c5bb44d292e3f054d2612240',1,'ScoreManager']]]
];
