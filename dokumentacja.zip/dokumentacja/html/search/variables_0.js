var searchData=
[
  ['invisibilityclock_0',['invisibilityClock',['../class_ball.html#a0361fc18a91dede32a2cb0c90a2cfb6d',1,'Ball']]],
  ['invisibilityduration_1',['invisibilityDuration',['../class_ball.html#a8c216b45c93e9020617ee8f1bd3abd87',1,'Ball']]]
];
