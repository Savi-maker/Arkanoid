var searchData=
[
  ['bufftype_0',['BuffType',['../_buff_8h.html#af2698b3717f3617f4450dcd130fd3529',1,'Buff.h']]]
];
