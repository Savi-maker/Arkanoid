var searchData=
[
  ['savescores_0',['saveScores',['../class_score_manager.html#aa3f390fe5076324b2d457de0c43af59f',1,'ScoreManager']]],
  ['scoremanager_1',['ScoreManager',['../class_score_manager.html',1,'ScoreManager'],['../class_score_manager.html#a8952a17614ae60b3191a812728bd55fc',1,'ScoreManager::ScoreManager()']]],
  ['scoremanager_2ecpp_2',['ScoreManager.cpp',['../_score_manager_8cpp.html',1,'']]],
  ['scoremanager_2eh_3',['ScoreManager.h',['../_score_manager_8h.html',1,'']]],
  ['scoremultiplier_4',['ScoreMultiplier',['../_buff_8h.html#af2698b3717f3617f4450dcd130fd3529a31f6f99f6ac92561e21b26bde759bbc7',1,'Buff.h']]],
  ['setinvisible_5',['setInvisible',['../class_ball.html#a8445dbb07dda6358b3b29e642e335820',1,'Ball']]],
  ['setradius_6',['setRadius',['../class_ball.html#a7f8d844948ccc5111ee4b60cdb3ed42f',1,'Ball']]],
  ['setreversecontrols_7',['setReverseControls',['../class_paddle.html#a63e52094b6c463cafe6260333d59ebd3',1,'Paddle']]],
  ['setsize_8',['setSize',['../class_paddle.html#af4eea860e4c267644e5da8f7fe2446a6',1,'Paddle']]],
  ['setvelocity_9',['setVelocity',['../class_ball.html#a9b4ac3f1e7a76104005df37e954e3ff0',1,'Ball::setVelocity()'],['../class_paddle.html#a2acdc3dc0a8fd8d4b9c6e7acf593a26f',1,'Paddle::setVelocity()']]],
  ['sizedown_10',['SizeDown',['../_buff_8h.html#af2698b3717f3617f4450dcd130fd3529a35629c063271c496e1e23d0961d0f335',1,'Buff.h']]],
  ['sizeup_11',['SizeUp',['../_buff_8h.html#af2698b3717f3617f4450dcd130fd3529aebe84ee3d1a4d2249b8f589592fd12ca',1,'Buff.h']]],
  ['speeddown_12',['SpeedDown',['../_buff_8h.html#af2698b3717f3617f4450dcd130fd3529a1a3b5cdb6751d06ac5eceb4e12ab23b0',1,'Buff.h']]],
  ['speedup_13',['SpeedUp',['../_buff_8h.html#af2698b3717f3617f4450dcd130fd3529adf0619cd002fcf6664a1148022cff99f',1,'Buff.h']]],
  ['start_14',['Start',['../class_poziom1.html#a03dd1f10b4eee21dc538122f20572952',1,'Poziom1::Start()'],['../class_poziom2.html#a2b01ba9403e0e763aa22011995ef5551',1,'Poziom2::Start()'],['../class_poziom3.html#a7683e562ee6b3a282804cfa55c0f917b',1,'Poziom3::Start()'],['../class_poziom4.html#af5d072e0a8ad9c32a3e4e8a724973531',1,'Poziom4::Start()'],['../class_poziom5.html#a7663dfb5546758ffd4a97fa1901798ed',1,'Poziom5::Start()'],['../class_poziom6.html#a0f0f0efb08690647d33d9486efb1c5ed',1,'Poziom6::Start()']]]
];
