var searchData=
[
  ['getheight_0',['getHeight',['../class_paddle.html#a6089d882922a3e905d4ec2a1be1b90de',1,'Paddle']]],
  ['getposition_1',['getPosition',['../class_ball.html#a70e88464efdf5fcbffe8e5fbeb706076',1,'Ball::getPosition()'],['../class_block.html#a3dddb8c3c22a3154a9ad3f98c3455910',1,'Block::getPosition()'],['../class_paddle.html#af0bbc74e9d5c0e245fa75abee11641e3',1,'Paddle::getPosition()']]],
  ['getradius_2',['getRadius',['../class_ball.html#ac93d35a55e06ca1a406cf3cbc49f4e12',1,'Ball']]],
  ['getscores_3',['getScores',['../class_score_manager.html#a6c3d036e25b3c2cea4e34ed8c00442e8',1,'ScoreManager']]],
  ['getshape_4',['getShape',['../class_block.html#a1b8e2698d5512920270e4d436370cfc9',1,'Block']]],
  ['getsize_5',['getSize',['../class_block.html#a34274a6fdbb0335f7523d525358a7ddd',1,'Block']]],
  ['gettype_6',['getType',['../class_buff.html#a42fcc80f65cb698315a41fe383d00f52',1,'Buff']]],
  ['getvelocity_7',['getVelocity',['../class_ball.html#a68663f04c2d092fa4dd3a2fddee79a44',1,'Ball::getVelocity()'],['../class_paddle.html#a129328c6ac3ffe8d8e34648c107d024a',1,'Paddle::getVelocity() const']]],
  ['getwidth_8',['getWidth',['../class_paddle.html#ae0b980f31e309cbebb845067f8c830cb',1,'Paddle']]]
];
