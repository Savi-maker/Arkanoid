var searchData=
[
  ['reseteffect_0',['resetEffect',['../class_buff.html#aa6eb871d1a1442256cc9b6d9a66ec8a8',1,'Buff']]],
  ['reversecontrols_1',['ReverseControls',['../_buff_8h.html#af2698b3717f3617f4450dcd130fd3529acb98bbc1f358f2ed772698087597c529',1,'Buff.h']]],
  ['right_2',['right',['../class_ball.html#abc41f7a60b5e5589c5d28e764e647408',1,'Ball::right()'],['../class_block.html#a38be557b4ae9b9a02b0bd226da24b1be',1,'Block::right()'],['../class_buff.html#abf7c917bd448aa368d75d073503f3db3',1,'Buff::right()'],['../class_paddle.html#af61d36c2aa66085731eba97f31640f86',1,'Paddle::right()']]]
];
