var searchData=
[
  ['fall_0',['fall',['../class_buff.html#a8b4679a61a8bed9a7ec015f6a0968697',1,'Buff']]]
];
