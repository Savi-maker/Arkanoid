var searchData=
[
  ['operator_3d_0',['operator=',['../class_buff.html#aea1d945019a79aff0e90cadc1b3529e2',1,'Buff']]]
];
