var class_poziom6 =
[
    [ "Start", "class_poziom6.html#a0f0f0efb08690647d33d9486efb1c5ed", null ]
];