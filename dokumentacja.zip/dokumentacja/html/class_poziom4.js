var class_poziom4 =
[
    [ "~Poziom4", "class_poziom4.html#a80fa3a47c67a53ff002c640701f562aa", null ],
    [ "Start", "class_poziom4.html#af5d072e0a8ad9c32a3e4e8a724973531", null ]
];