var _buff_8h =
[
    [ "Buff", "class_buff.html", "class_buff" ],
    [ "BuffType", "_buff_8h.html#af2698b3717f3617f4450dcd130fd3529", [
      [ "SpeedUp", "_buff_8h.html#af2698b3717f3617f4450dcd130fd3529adf0619cd002fcf6664a1148022cff99f", null ],
      [ "SpeedDown", "_buff_8h.html#af2698b3717f3617f4450dcd130fd3529a1a3b5cdb6751d06ac5eceb4e12ab23b0", null ],
      [ "SizeUp", "_buff_8h.html#af2698b3717f3617f4450dcd130fd3529aebe84ee3d1a4d2249b8f589592fd12ca", null ],
      [ "SizeDown", "_buff_8h.html#af2698b3717f3617f4450dcd130fd3529a35629c063271c496e1e23d0961d0f335", null ],
      [ "ReverseControls", "_buff_8h.html#af2698b3717f3617f4450dcd130fd3529acb98bbc1f358f2ed772698087597c529", null ],
      [ "BallSpeedUp", "_buff_8h.html#af2698b3717f3617f4450dcd130fd3529ab58fa10f2874c80405aae5c4529f166d", null ],
      [ "BallSpeedDown", "_buff_8h.html#af2698b3717f3617f4450dcd130fd3529a3331688e04c3eeee017b4a6f7d945231", null ],
      [ "PaddleSpeedUp", "_buff_8h.html#af2698b3717f3617f4450dcd130fd3529a704d112cbc3504a3e29bd0ab67988481", null ],
      [ "PaddleSpeedDown", "_buff_8h.html#af2698b3717f3617f4450dcd130fd3529a6790015c0998d9520b6fd236571421c5", null ],
      [ "ScoreMultiplier", "_buff_8h.html#af2698b3717f3617f4450dcd130fd3529a31f6f99f6ac92561e21b26bde759bbc7", null ]
    ] ]
];