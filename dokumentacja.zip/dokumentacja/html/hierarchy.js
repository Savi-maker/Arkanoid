var hierarchy =
[
    [ "Drawable", null, [
      [ "Ball", "class_ball.html", null ],
      [ "Block", "class_block.html", null ]
    ] ],
    [ "sf::Drawable", null, [
      [ "Buff", "class_buff.html", null ],
      [ "Paddle", "class_paddle.html", null ]
    ] ],
    [ "MainMenu", "class_main_menu.html", null ],
    [ "Poziom1", "class_poziom1.html", null ],
    [ "Poziom2", "class_poziom2.html", null ],
    [ "Poziom3", "class_poziom3.html", null ],
    [ "Poziom4", "class_poziom4.html", null ],
    [ "Poziom5", "class_poziom5.html", null ],
    [ "Poziom6", "class_poziom6.html", null ],
    [ "ScoreManager", "class_score_manager.html", null ]
];