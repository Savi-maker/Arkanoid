var class_poziom1 =
[
    [ "~Poziom1", "class_poziom1.html#a0f37385873edba83de45821d27855dde", null ],
    [ "Start", "class_poziom1.html#a03dd1f10b4eee21dc538122f20572952", null ]
];