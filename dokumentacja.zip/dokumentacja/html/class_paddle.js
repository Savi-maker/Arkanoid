var class_paddle =
[
    [ "Paddle", "class_paddle.html#a04da494d13740299c03481c932199013", null ],
    [ "~Paddle", "class_paddle.html#ac03c6b92f0b9cd2e67edff4c318ad030", null ],
    [ "bottom", "class_paddle.html#a9c19cce54630a444242f1c993516adbc", null ],
    [ "draw", "class_paddle.html#a8086c5f5dc90749022cc3eb2ebdfe197", null ],
    [ "getHeight", "class_paddle.html#a6089d882922a3e905d4ec2a1be1b90de", null ],
    [ "getPosition", "class_paddle.html#af0bbc74e9d5c0e245fa75abee11641e3", null ],
    [ "getVelocity", "class_paddle.html#a129328c6ac3ffe8d8e34648c107d024a", null ],
    [ "getWidth", "class_paddle.html#ae0b980f31e309cbebb845067f8c830cb", null ],
    [ "left", "class_paddle.html#a8ea5fff3052f2f8e2275bf72ee965496", null ],
    [ "moveLeft", "class_paddle.html#a757d8913b856088398deb4ec9780a94b", null ],
    [ "moveRight", "class_paddle.html#ad143c9de8342378c3153d7ed06bd3ca4", null ],
    [ "right", "class_paddle.html#af61d36c2aa66085731eba97f31640f86", null ],
    [ "setReverseControls", "class_paddle.html#a63e52094b6c463cafe6260333d59ebd3", null ],
    [ "setSize", "class_paddle.html#af4eea860e4c267644e5da8f7fe2446a6", null ],
    [ "setVelocity", "class_paddle.html#a2acdc3dc0a8fd8d4b9c6e7acf593a26f", null ],
    [ "top", "class_paddle.html#ac3704d938da3f50623db12493bc56fa6", null ],
    [ "update", "class_paddle.html#a840b626b2137bb9f754563d33693cfac", null ]
];