var class_poziom3 =
[
    [ "~Poziom3", "class_poziom3.html#a3c515e64e7f387be9ac4100f60abae13", null ],
    [ "Start", "class_poziom3.html#a7683e562ee6b3a282804cfa55c0f917b", null ]
];